# "Estabilidad de los Sistemas Lineales de Salto Markoviano en Tiempo Discreto", 2019.

Tesis de Licenciatura, Escuela Profesional de Matemática, Universidad Nacional de Ingeniería.

Resumen:La meta propuesta es caracterizar la estabilidad de un sistema lineal de salto Markoviano en tiempo discreto. Especficamente, se estudia el comportamiento de las soluciones del sistema dinámico discreto en un espacio Euclideano complejo x(k+1)=A_{θ(k)} x(k) cuando {θ(k)} es una cadena de Markov. Previamente, se estudian la teoría de estabilidad según Lyapunov en espacios Euclideanos complejos, sin considerar aleatoriedad, y algunas extensiones importantes. Luego, para un sistema lineal de salto Markoviano, se exhibe un marco estocástico natural que deriva de él y que permite el análisis conductual de las soluciones. Finalmente, una vez definida operativamente la noción de estabilidad media cuadrática se establecen diversas caracterizaciones, algunas derivadas de la teoría de Lyapunov antes estudiada, así como se revisan diversos ejemplos.

